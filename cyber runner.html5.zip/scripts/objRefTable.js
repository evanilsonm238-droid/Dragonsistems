const C3 = self.C3;
self.C3_GetObjectRefTable = function () {
	return [
		C3.Plugins.Sprite,
		C3.Behaviors.TileMovement,
		C3.Plugins.Keyboard,
		C3.Plugins.Mouse,
		C3.Behaviors.MoveTo,
		C3.Behaviors.Bullet,
		C3.Plugins.Keyboard.Cnds.IsKeyDown,
		C3.Behaviors.TileMovement.Acts.SimulateControl,
		C3.Plugins.Sprite.Acts.SetAnim,
		C3.Plugins.Sprite.Cnds.OnCollision,
		C3.Plugins.Mouse.Cnds.IsButtonDown,
		C3.Plugins.Sprite.Acts.SetVisible,
		C3.Plugins.System.Cnds.EveryTick,
		C3.Behaviors.MoveTo.Acts.MoveToObject,
		C3.Plugins.Mouse.Cnds.OnClick,
		C3.Plugins.System.Acts.CreateObject,
		C3.Plugins.Sprite.Exps.X,
		C3.Plugins.Sprite.Exps.Y
	];
};
self.C3_JsPropNameTable = [
	{Sprite: 0},
	{Sprite2: 0},
	{MovimentoEmGrid: 0},
	{Sprite3: 0},
	{Teclado: 0},
	{Mouse: 0},
	{Sprite4: 0},
	{Sprite6: 0},
	{MoverPara: 0},
	{Sprite5: 0},
	{Projétil: 0},
	{Sprite7: 0}
];

self.InstanceType = {
	Sprite: class extends self.ISpriteInstance {},
	Sprite2: class extends self.ISpriteInstance {},
	Sprite3: class extends self.ISpriteInstance {},
	Teclado: class extends self.IInstance {},
	Mouse: class extends self.IInstance {},
	Sprite4: class extends self.ISpriteInstance {},
	Sprite6: class extends self.ISpriteInstance {},
	Sprite5: class extends self.ISpriteInstance {},
	Sprite7: class extends self.ISpriteInstance {}
}